import { Injectable } from '@angular/core';
import { HttpClient} from '@angular/common/http';
import { map } from 'rxjs/internal/operators/map';
import { of } from 'rxjs/internal/observable/of';
import { tap } from 'rxjs/internal/operators/tap';
import { environment } from 'src/environments/environment';


@Injectable({
  providedIn: 'root'
})
export class WebservicesService {

  public serviceUrl = environment.serviceUrl;

  constructor(
    public Http: HttpClient
  ) { }

  public Login(email: any, password: any) {
    const url = `${this.serviceUrl}/AccountMaster/Login`;
    const body = { Email: email, Password: password, Condition: "check_Login" }
    return this.Http.post<any>(url, body).pipe(
     // tap(d => console.log(d)),
      map(d => (d.Status_cd !== "0") ?  Object.assign(d.ds.Table[0], { link: d.ds.Table1[0].EmailPwd }) : 'failed')
    )
  }

  public Register(data: any) {
    const url = `${this.serviceUrl}/AccountMaster/Signup`;
    const body = { Name: data.fullname, Email: data.email, Mobile: data.mobile, Password: data.password, SponserId: data.sponserid, Condition: "Insert" }
    return this.Http.post<any>(url, body).pipe(
      map(d => (d.Status_cd !== "0") ? d.ds.Table : 'failed')
    )
  }

  public async Token(): Promise<any> {
    try {
      return new Promise((resolve, reject) => {
        const url = `${this.serviceUrl}/Token`;
        const body = {
          "Username": "cobraadmin",
          "Password": "news123@cobra"
        };
        return this.Http.post<any>(url, body)
          .pipe(
            // tap(d => console.log('test', d)),
            map(d => (d.code === 1) ? d.document.accessToken : false))
          .subscribe((r: any) => resolve(r), reject);
      }).catch(err => console.log(err));
    } catch (error) {
      console.log(error);
    }
  }
  newsdata(): Promise<any> {
    try {
      return new Promise((resolve, reject) => {
        const url = `${this.serviceUrl}/UT_News_Category?page=1&itemsPerPage=100`;
        this.Http.get(url)
          .pipe(
            map((d: any) => (d.code === 1 ? d.document.records : false)))
          .subscribe((r: any) => resolve(r), reject)
      });
    } catch (error) {
      console.log(error)
    }
  }

  newscontents(): Promise<any> {
    try {
      return new Promise((resolve, reject) => {
        const url = `${this.serviceUrl}/UT_News_Content?page=1&itemsPerPage=100`;
        this.Http.get(url).pipe(
            map((d: any) => (d.code === 1 ? d.document.records : false)))
          .subscribe((r: any) => resolve(r), reject)
      });
    } catch (error) {
      console.log(error)
    }
  }

  movies(): Promise<any> {
    try {
      return new Promise((resolve, reject) => {
        const url = `${this.serviceUrl}/UT_Movie_Schedules?page=1&itemsPerPage=100`;
        this.Http.get(url)
          .pipe(
            map((d: any) => (d.code === 1 ? d.document.records : false)))
          .subscribe((r: any) => resolve(r), reject)
      });
    } catch (error) {
      console.log(error)
    }
  }


}
