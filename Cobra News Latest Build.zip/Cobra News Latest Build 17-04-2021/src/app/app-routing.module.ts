import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { BodyComponent } from './body/body.component';

const routes: Routes = [
  {
    path: '',
    component: BodyComponent,
    children: [
      { path: '', loadChildren: () => import('./pages/home/home.module').then(m => m.HomeModule) },
      { path: 'about', loadChildren: () => import('./pages/about/about.module').then(m => m.AboutModule) },
      { path: 'contact', loadChildren: () => import('./pages/contact/contact.module').then(m => m.ContactModule) },
      { path: 'LatestNews', loadChildren: () => import('./pages/latest-news/latest-news.module').then(m => m.LatestNewsModule) },
      { path: 'LatestNewsByCategory', loadChildren: () => import('./pages/latest-news-by-category/latest-news-by-category.module').then(m => m.LatestNewsByCategoryModule) },
      { path: 'world', loadChildren: () => import('./pages/world/world.module').then(m => m.WorldModule) },
      { path: 'vedios', loadChildren: () => import('./pages/vedios/vedios.module').then(m => m.VediosModule) },
      { path: 'nation/:name/:newsCategoryId', loadChildren: () => import('./pages/nation/nation.module').then(m => m.NationModule) },
      { path: 'ComingSoon', loadChildren: () => import('./pages/commingsoon/commingsoon.module').then(m => m.CommingsoonModule) },
      { path: 'fir', loadChildren: () => import('./pages/fir/fir.module').then(m => m.FirModule) },
      { path: 'films', loadChildren: () => import('./pages/films/films.module').then(m => m.FilmsModule) },
      { path: 'truecrimestories', loadChildren: () => import('./pages/truecrimestories/truecrimestories.module').then(m => m.TruecrimestoriesModule) },
      { path: 'movies', loadChildren: () => import('./pages/movies/movies.module').then(m => m.MoviesModule) },
      { path: 'detailnews/:Newsname/:NewsId', loadChildren: () => import('./pages/detailnews/detailnews.module').then(m => m.DetailnewsModule) },
      { path: 'mostpopular', loadChildren: () => import('./pages/mostpopular/mostpopular.module').then(m => m.MostpopularModule) },
      { path: 'reviewdetails/:reviewid', loadChildren: () => import('./pages/reviewdetails/reviewdetails.module').then(m => m.ReviewdetailsModule) },
      { path: 'vediosdetails/:type/:vedioId', loadChildren: () => import('./pages/vediosdetails/vediosdetails.module').then(m => m.VediosdetailsModule) },
      { path: 'moviedetails/:movieId', loadChildren: () => import('./pages/moviedetails/moviedetails.module').then(m => m.MoviedetailsModule) },
      { path: 'reviewdetails/:reviewid', loadChildren: () => import('./pages/reviewdetails/reviewdetails.module').then(m => m.ReviewdetailsModule) },

    ]
  },

];

@NgModule({
  imports: [RouterModule.forRoot(routes, {
    initialNavigation: 'enabled',
    scrollPositionRestoration: 'enabled'
  })],
  exports: [RouterModule]
})
export class AppRoutingModule { }
