import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { DetailnewsComponent } from './detailnews.component';
import { DetailNewsService } from './detailnews.service';

const routes: Routes = [{ path: '', component: DetailnewsComponent,}];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class DetailnewsRoutingModule { }
