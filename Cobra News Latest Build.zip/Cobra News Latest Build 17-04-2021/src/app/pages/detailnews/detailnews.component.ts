import { Component, OnInit, OnDestroy } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { first } from 'rxjs/operators';
import { DetailNewsService } from './detailnews.service';

@Component({
  selector: 'app-detailnews',
  templateUrl: './detailnews.component.html',
  styleUrls: ['./detailnews.component.scss']
})
export class DetailnewsComponent implements OnInit, OnDestroy {

  latestnewsdetails: any;
  newsData: any = [];
  news_heading: any = [];
  newstemp_arr: any = [];
  latestnews: any;
  id: number;
  MyordersLoader=true
  private sub: any;
  name: any;
  constructor(
    private ActivateRoute: ActivatedRoute,
    private DetailNews_Service: DetailNewsService,
  ) { }

  ngOnInit(): void {
    this.sub = this.ActivateRoute.params.subscribe((params) => {
      this.id = params['NewsId'];
      this.name = params['Newsname']
      this.DetailNews_Service.newsdata_filter(this.id).then((res) => {
        this.MyordersLoader=false
        if(res){
          this.latestnewsdetails = res[0];
        }
        // console.log(this.latestnewsdetails)
      });
    });

    this.DetailNews_Service.newsdata().then((r) => {
      const heading = r;
      this.DetailNews_Service.newscontents().then((n) => {
        const content = n;
        heading.map((x: any) => {
          let value = content.filter(
            (f: any) => f.newsCategoryId === x.newsCategoryId && x.status !== false
          );
          let key = x.newsCategoryName;
          this.newsData.push({
            newsCategoryName: x.newsCategoryName,
            newsCategoryId: x.newsCategoryId,
            array: value,
          });
          // this.newstemp_arr.
        });
      });
    });

  }

  ngOnDestroy() {
    this.sub.unsubscribe();
  }


}
