import { Injectable } from "@angular/core";
import { ActivatedRouteSnapshot } from "@angular/router";
import { map } from "rxjs/internal/operators/map";

import { HttpClient } from '@angular/common/http';
import { tap } from 'rxjs/internal/operators/tap';
import { WebservicesService } from "src/services/webapis";
import { forkJoin } from "rxjs";


@Injectable({ providedIn: "root" })
export class DetailNewsService {
  Accountno: any;
 

  constructor(
    private HttpClient: HttpClient,
    private service: WebservicesService
  ) { }




newsdata_filter(filter_value): Promise<any> {
    try {
      return new Promise((resolve, reject) => {
        const url = `${this.service.serviceUrl}/UT_News_Content/filter?andOr=AND&page=1&itemsPerPage=100`;
        let body = [{
            "columnName": "sno",
            "columnValue": filter_value
          }]
        this.HttpClient.post(url,body)
        .pipe(
            map((d: any) => (d.code === 1 ? d.document.records : false)))
          .subscribe((r: any) => resolve(r), reject);
      });
    } catch (error) {
      console.log(error)
    }
  }

  newsdata(): Promise<any> {
    try {
      return new Promise((resolve, reject) => {
        const url = `${this.service.serviceUrl}/UT_News_Category?page=1&itemsPerPage=100`;
        this.HttpClient.get(url)
          .pipe(
            map((d: any) => (d.code === 1 ? d.document.records : false)))
          .subscribe((r: any) => resolve(r), reject)
      });
    } catch (error) {
      console.log(error)
    }
  }

  newscontents(): Promise<any> {
    try {
      return new Promise((resolve, reject) => {
        const url = `${this.service.serviceUrl}/UT_News_Content?page=1&itemsPerPage=100`;
        this.HttpClient.get(url)
          .pipe( 
            map((d: any) => (d.code === 1 ? d.document.records : false)))
          .subscribe((r: any) => resolve(r), reject)
      });
    } catch (error) {
      console.log(error)
    }
  }


}
