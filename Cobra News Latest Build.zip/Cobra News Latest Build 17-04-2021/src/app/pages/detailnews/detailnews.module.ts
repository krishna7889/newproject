import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { DetailnewsRoutingModule } from './detailnews-routing.module';
import { DetailnewsComponent } from './detailnews.component';
import { CommonsidebarModule } from '../commonsidebar/commonsidebar.module';


@NgModule({
  declarations: [DetailnewsComponent],
  imports: [
    CommonModule,
    DetailnewsRoutingModule,
    CommonsidebarModule
  ]
})
export class DetailnewsModule { }
