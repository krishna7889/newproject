import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReviewdetailsComponent } from './reviewdetails.component';
import { ReviewsRoutingModule } from './reviewsdetails.routing';
import { CommonsidebarModule } from '../commonsidebar/commonsidebar.module';



@NgModule({
  declarations: [ReviewdetailsComponent],
  imports: [
    CommonModule,
    ReviewsRoutingModule,
    CommonsidebarModule,
  ]
})
export class ReviewdetailsModule { }
