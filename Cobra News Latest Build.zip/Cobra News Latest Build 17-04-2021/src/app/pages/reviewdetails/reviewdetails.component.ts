import { Component, OnInit, OnDestroy } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { first } from 'rxjs/operators';
import { MoviedetailsService } from '../moviedetails/moviedetails.service';
import { ReviewdetailsService } from './reviewdetails.service';

@Component({
  selector: 'app-reviewdetails',
  templateUrl: './reviewdetails.component.html',
  styleUrls: ['./reviewdetails.component.scss']
})
export class ReviewdetailsComponent implements OnInit, OnDestroy {
  reviewservices: any;
  reviewsdata: any;
  private sub: any;
  moviesdata: any;
  id: any;
  MyordersLoader=true
  constructor(
    private ActivateRoute: ActivatedRoute,
    private reviewdetailser: ReviewdetailsService
  ) { }

  ngOnInit(): void {
    this.sub = this.ActivateRoute.params.subscribe((params) => {
      this.id = params['reviewid'];
      this.reviewdetailser.reviews_filter(this.id).then((res) => {
        this.MyordersLoader=false
        if(res){
        this.reviewservices = res[0];

        }
      });
    });

    this.getreviews();
    this.getmovies();
  }
  ngOnDestroy() {
    this.sub.unsubscribe();
  }

  getreviews() {
    this.reviewdetailser.moviereviews().then(res => {
      if (res) {
        this.reviewsdata = res
        // this.reviewsdata[0].status=false
        // console.log(this.reviewsdata)
      }
    })
  }

  getmovies() {
    this.reviewdetailser.movies().then(res => {
      if (res) {
        this.moviesdata = res
        // this.moviesdata[0].status=false
        // console.log(this.moviesdata)
      }
    })
  }

}
