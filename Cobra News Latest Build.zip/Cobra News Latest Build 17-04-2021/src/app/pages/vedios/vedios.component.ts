import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { first } from 'rxjs/operators';
import { DomSanitizer } from '@angular/platform-browser';
import { VediosService } from './vedios.service';

@Component({
  selector: 'app-vedios',
  templateUrl: './vedios.component.html',
  styleUrls: ['./vedios.component.scss']
})
export class VediosComponent implements OnInit {
  vediosdata: any;
  config: any;
  collection = { count: 0, data: [] };
  MyordersLoader: boolean = true

  constructor(
    private ActivateRoute: ActivatedRoute,
    public sanitizer: DomSanitizer,
    private vedioser: VediosService
  ) { }

  ngOnInit(): void {
    this.vedioser.vediosdata().then(res => {
      this.vediosdata=[]
      this.MyordersLoader= false
      if (res) {
        this.vediosdata = res
        this.collection = { count: this.vediosdata.length - 1, data: [...this.vediosdata] }
        // this.vediosdata[0].status=false
        // console.log(this.vediosdata)
      }
    })
    this.config = {
      itemsPerPage: 5,
      currentPage: 1,
      totalItems: this.collection.count

    };

  }
  pageChanged(event) {
    this.config.currentPage = event;
    window.scrollTo({ top: 0, behavior: 'smooth' })
  }
  SafeYoutue(url: any) {
    const d = 'https://youtu.be/ufgcxiKEe08' + url;
    return this.sanitizer.bypassSecurityTrustResourceUrl(d)

  }

}
