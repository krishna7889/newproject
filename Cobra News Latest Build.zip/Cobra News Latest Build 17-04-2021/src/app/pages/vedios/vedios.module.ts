import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { VediosRoutingModule } from './vedios-routing';
import { VediosComponent } from './vedios.component';
import { CommonsidebarModule } from '../commonsidebar/commonsidebar.module';
import { SafePipeModule } from 'src/app/pipes/safe.module';
import { NgxPaginationModule } from 'ngx-pagination';


@NgModule({
  declarations: [VediosComponent],
  imports: [
    CommonModule,
    VediosRoutingModule,
    CommonsidebarModule,
    SafePipeModule,
    NgxPaginationModule
  ]
})
export class VediosModule { }
