import { Injectable } from '@angular/core';
import { map } from 'rxjs/operators';
import { WebservicesService } from 'src/services/webapis';

@Injectable({
  providedIn: 'root'
})
export class VediosService {

  constructor(
    private service: WebservicesService
  ) { }
  // resolve() {
  //   return this.vediosdata()
  // }

  public async vediosdata(): Promise<any> {
    try {
      return new Promise((resolve, reject) => {
        const url = `${this.service.serviceUrl}/UT_Videos?page=1&itemsPerPage=100`;
        return this.service.Http.get<any>(url)
          .pipe(
            map(d => (d.code === 1) ? d.document.records : false))
          .subscribe((r: any) => resolve(r), reject);
      }).catch(err => console.log(err));
    } catch (error) {
      console.log(error);
    }
  }
}
