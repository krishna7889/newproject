import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { VediosComponent } from './vedios.component';
import { VediosService } from './vedios.service';

const routes: Routes = [{ path: '', component: VediosComponent,
// resolve:{Vedios:VediosService} 
}];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class VediosRoutingModule { }