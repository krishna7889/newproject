import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { TruecrimestoriesComponent } from './truecrimestories.component';
import { TruecrimeService } from './truecrimestories.service';

const routes: Routes = [{ path: '', component: TruecrimestoriesComponent,
resolve: { crimenewsservice: TruecrimeService } 

}];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class TruecrimestoriesRoutingModule { }
