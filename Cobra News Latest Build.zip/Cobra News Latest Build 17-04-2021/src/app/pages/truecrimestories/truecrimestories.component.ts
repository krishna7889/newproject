import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { first } from 'rxjs/operators';

@Component({
  selector: 'app-truecrimestories',
  templateUrl: './truecrimestories.component.html',
  styleUrls: ['./truecrimestories.component.scss']
})
export class TruecrimestoriesComponent implements OnInit {
  crimenews: any;

  constructor(
    private ActivateRoute: ActivatedRoute,
    private route:Router
  ) { }

  ngOnInit(): void {
    this.ActivateRoute.data.pipe(first()).subscribe((res) => {
      if (res.crimenewsservice) {
            this.crimenews = res.crimenewsservice
      }
    })
  }

  crimedetails(data){
    localStorage.removeItem('crimeData');
    localStorage.setItem('crimeData',JSON.stringify(data));
    this.route.navigateByUrl("truecrimedetails");
  }

}
