import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { TruecrimestoriesRoutingModule } from './truecrimestories-routing.module';
import { TruecrimestoriesComponent } from './truecrimestories.component';
import { CommonsidebarModule } from '../commonsidebar/commonsidebar.module';


@NgModule({
  declarations: [TruecrimestoriesComponent],
  imports: [
    CommonModule,
    TruecrimestoriesRoutingModule,
    CommonsidebarModule
  ]
})
export class TruecrimestoriesModule { }
