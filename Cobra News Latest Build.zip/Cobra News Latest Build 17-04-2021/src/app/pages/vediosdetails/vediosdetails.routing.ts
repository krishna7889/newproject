import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { VediosdetailsComponent } from './vediosdetails.component';
import { VediosdetailsService } from './vediosdetails.service';



const routes: Routes = [{ path: '', component: VediosdetailsComponent
 }];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class VediosdetailsRoutingModule { }
