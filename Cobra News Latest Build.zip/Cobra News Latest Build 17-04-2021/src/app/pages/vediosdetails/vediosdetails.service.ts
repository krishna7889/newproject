import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot } from '@angular/router';
import { map } from 'rxjs/operators';
import { HttpClient } from '@angular/common/http';
import { WebservicesService } from 'src/services/webapis';

@Injectable({
  providedIn: 'root'
})
export class VediosdetailsService {
  type: any;

  constructor(
    private HttpClient: HttpClient,
    private service: WebservicesService
  ) { }

  latest_vedios(myDate): Promise<any> {
    try {
      return new Promise((resolve, reject) => {
        let body = [{

          "columnName": "sno",
          "columnValue": myDate
        }]
        const url = `${this.service.serviceUrl}/UT_Videos/filter?andOr=AND&page=1&itemsPerPage=100`;
        this.HttpClient.post(url,body)
        .pipe(
            map((d: any) => (d.code === 1 ? d.document.records : false)))
          .subscribe((r: any) => resolve(r), reject);
      });
    } catch (error) {
      console.log(error)
    }
  }
  moviertrailers_filter(myDate): Promise<any> {
    try {
      return new Promise((resolve, reject) => {
        const url = `${this.service.serviceUrl}/UT_Trailers/filter?andOr=AND&page=1&itemsPerPage=100`;
        let body = [{

          "columnName": "sno",
          "columnValue": myDate
        }]
        this.HttpClient.post(url,body)
          .pipe( 
            map((d: any) => (d.code === 1 ? d.document.records : false)))
          .subscribe((r: any) => resolve(r), reject)
      });
    } catch (error) {
      console.log(error)
    }
  }

  public async vediosdata(): Promise<any> {
    try {
      return new Promise((resolve, reject) => {
        const url = `${this.service.serviceUrl}/UT_Videos?page=1&itemsPerPage=100`;
        return this.service.Http.get<any>(url)
          .pipe(
            map(d => (d.code === 1) ? d.document.records : false))
          .subscribe((r: any) => resolve(r), reject);
      }).catch(err => console.log(err));
    } catch (error) {
      console.log(error);
    }
  }

  movietrailers(): Promise<any> {
    try {
      return new Promise((resolve, reject) => {
        const url = `${this.service.serviceUrl}/UT_Trailers?page=1&itemsPerPage=100`;
        this.HttpClient.get(url)
          .pipe( 
            map((d: any) => (d.code === 1 ? d.document.records : false)))
          .subscribe((r: any) => resolve(r), reject)
      });
    } catch (error) {
      console.log(error)
    }
  }
}
