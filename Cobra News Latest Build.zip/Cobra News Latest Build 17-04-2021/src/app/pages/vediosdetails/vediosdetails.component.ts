import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { first } from 'rxjs/operators';
import { VediosdetailsService } from './vediosdetails.service';
import { DomSanitizer } from '@angular/platform-browser';

@Component({
  selector: 'app-vediosdetails',
  templateUrl: './vediosdetails.component.html',
  styleUrls: ['./vediosdetails.component.scss']
})
export class VediosdetailsComponent implements OnInit {
  vediostails: any;
  trailers: any;
  private sub: any;
  id: number;
  type: any
  videos: any;
  MyordersLoader = true

  constructor(
    private ActivateRoute: ActivatedRoute,
    private videoService: VediosdetailsService,
    public sanitizer: DomSanitizer,

  ) { }

  ngOnInit(): void {
    this.sub = this.ActivateRoute.params.subscribe((params) => {
      this.id = params['vedioId'];
      this.type = params['type'];
      if (this.type == 'traliers') {
        this.videoService.moviertrailers_filter(this.id).then((res) => {
          if (res) {
            this.vediostails = res[0];
          }

        });
      }
      else {
        this.videoService.latest_vedios(this.id).then((res) => {
          this.vediostails = res[0];
        });
      }

    });
    this.gettrailers();
    this.getvideos();
  }
  ngOnDestroy() {
    this.sub.unsubscribe();
  }

  SafeYoutue(url: any) {
    const d = 'https://youtu.be/ufgcxiKEe08' + url;
    return this.sanitizer.bypassSecurityTrustResourceUrl(d)

  }
  gettrailers() {
    this.videoService.movietrailers().then(res => {
      this.MyordersLoader = false
      if (res) {
        this.trailers = res

        // this.trailers[0].status=false
        // console.log(this.trailers)
      }
    })
  }

  getvideos() {
    this.videoService.vediosdata().then(res => {
      if (res) {
        this.videos = res
        // this.videos[0].status=false
        // console.log(this.videos)
      }
    })
  }
}
