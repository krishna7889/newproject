import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { VediosdetailsComponent } from './vediosdetails.component';
import { VediosdetailsRoutingModule } from './vediosdetails.routing';
import { CommonsidebarModule } from '../commonsidebar/commonsidebar.module';
import { SafePipeModule } from 'src/app/pipes/safe.module';



@NgModule({
  declarations: [VediosdetailsComponent],
  imports: [
    CommonModule,
    VediosdetailsRoutingModule,
    CommonsidebarModule,
    SafePipeModule
  ]
})
export class VediosdetailsModule { }
