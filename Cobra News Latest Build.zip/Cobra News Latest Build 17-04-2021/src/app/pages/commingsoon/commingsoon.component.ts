import { Component, OnInit } from '@angular/core';
declare var $;

@Component({
  selector: 'app-commingsoon',
  templateUrl: './commingsoon.component.html',
  styleUrls: ['./commingsoon.component.scss']
})
export class CommingsoonComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
    
  }
}
