import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CommingsoonComponent } from './commingsoon.component';
import { CommingsoonRoutingModule } from './comming-routing';
import { CommonsidebarModule } from '../commonsidebar/commonsidebar.module';

@NgModule({
  declarations: [CommingsoonComponent],
  imports: [
    CommonModule,
    CommingsoonRoutingModule,
    CommonsidebarModule
  ]
})
export class CommingsoonModule { }
