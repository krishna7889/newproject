import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { first } from 'rxjs/operators';
import { WorldService } from './world.service';


@Component({
  selector: 'app-world',
  templateUrl: './world.component.html',
  styleUrls: ['./world.component.scss']
})
export class WorldComponent implements OnInit {
  worlddata: any;


  constructor(
  private wordserv:WorldService,
  private ActivateRoute: ActivatedRoute,
  ) { }

  ngOnInit(): void {

    this.ActivateRoute.data.pipe(first()).subscribe((res) => {
      if (res.world) {
        this.worlddata  = res.world
      }
    })
  }

}
