import { Injectable } from "@angular/core";
import { ActivatedRouteSnapshot } from "@angular/router";
import { HttpClient } from '@angular/common/http';
import { WebservicesService } from "src/services/webapis";
import { map } from "rxjs/operators";


@Injectable({ providedIn: "root" })
export class WorldService {
    
  resolve(route: ActivatedRouteSnapshot) {
  return this.newsdata_filter()
  }

  constructor(
    private HttpClient: HttpClient,
    private service: WebservicesService
  ) { }
  reslove(){
    return this.newsdata_filter()
  }
  newsdata_filter(): Promise<any> {
    try {
      return new Promise((resolve, reject) => {
        const url = `${this.service.serviceUrl}/UT_News_Content/filter?andOr=AND&page=1&itemsPerPage=100`;
        let body = [{
            "columnName": "newsCategoryId",
            "columnValue": "102"
          }]
        this.service.Http.post(url,body)
        .pipe(
            map((d: any) => (d.code === 1 ? d.document.records : false)))
          .subscribe((r: any) => resolve(r), reject);
      });
    } catch (error) {
      console.log(error)
    }
  }

}
