import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { WorldComponent } from './world.component';
import { WorldService } from './world.service';

const routes: Routes = [{ path: '', component: WorldComponent,
resolve: { world: WorldService } }];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class WorldRoutingModule { }
