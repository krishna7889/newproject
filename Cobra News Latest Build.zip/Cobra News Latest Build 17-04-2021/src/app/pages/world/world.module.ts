import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { WorldRoutingModule } from './world-routing.module';
import { WorldComponent } from './world.component';
import { CommonsidebarModule } from '../commonsidebar/commonsidebar.module';


@NgModule({
  declarations: [WorldComponent],
  imports: [
    CommonModule,
    WorldRoutingModule,
    CommonsidebarModule
  ]
})
export class WorldModule { }
