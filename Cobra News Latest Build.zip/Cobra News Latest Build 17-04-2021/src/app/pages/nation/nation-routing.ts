import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { NationComponent } from './nation.component';
import { NationService } from './nation.service';


const routes: Routes = [{ path: '', component: NationComponent,
// resolve: { getNationdata: NationService}
 }  ];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class NationRoutingModule { }
