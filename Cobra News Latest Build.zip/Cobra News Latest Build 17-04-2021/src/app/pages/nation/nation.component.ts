import { Component, OnInit, OnDestroy } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { first } from 'rxjs/operators';
import { WebservicesService } from 'src/services/webapis';
import { NationService } from './nation.service';

@Component({
  selector: 'app-nation',
  templateUrl: './nation.component.html',
  styleUrls: ['./nation.component.scss']
})
export class NationComponent implements OnInit, OnDestroy {
  nationdata: any=[];
  sub: any;
  id: any;
  name: any;
  collection = { count: 0, data: [] };
  config: any;
  MyordersLoader: boolean = true

  constructor(
    private ActivateRoute: ActivatedRoute,
    private service: WebservicesService,
    private route: Router,
    private nationser: NationService
  ) { }

  ngOnInit(): void {

    this.sub = this.ActivateRoute.params.subscribe((params) => {
      this.id = params['newsCategoryId'];
      this.name = params['name']
      this.nationser.newsdata_filter(this.id).then((res) => {
        this.nationdata=[]
        this.collection = { count: 0, data: [] };
        this.MyordersLoader = false
        this.config = {
          itemsPerPage: 5,
          currentPage: 1,
          totalItems: this.collection.count
    
        };
        if (res) {
          this.nationdata = res;
          this.collection = { count: this.nationdata.length - 1, data: [...this.nationdata] }
        }
      });
    });
  }
  ngOnDestroy() {
    this.sub.unsubscribe();
  }
  pageChanged(event) {
    this.config.currentPage = event;
    window.scrollTo({ top: 0, behavior: 'smooth' })
  }


}
