import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { NationComponent } from './nation.component';
import { NationRoutingModule } from './nation-routing';
import { CommonsidebarModule } from '../commonsidebar/commonsidebar.module';
import { NgxPaginationModule } from 'ngx-pagination';



@NgModule({
  declarations: [NationComponent],
  imports: [
    CommonModule,
    NationRoutingModule,
    CommonsidebarModule,
    NgxPaginationModule
  ]
})
export class NationModule { }
