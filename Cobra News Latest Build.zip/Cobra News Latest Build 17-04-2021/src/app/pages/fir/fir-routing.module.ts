import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { TruecrimeService } from '../truecrimestories/truecrimestories.service';

import { FirComponent } from './fir.component';
import { FIRService } from './fir.service';

const routes: Routes = [{ path: '', component: FirComponent,
resolve: { firservice: FIRService } 
}];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class FirRoutingModule { }




