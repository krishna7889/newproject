import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { first } from 'rxjs/operators';
import { FIRService } from './fir.service';


@Component({
  selector: 'app-fir',
  templateUrl: './fir.component.html',
  styleUrls: ['./fir.component.scss']
})
export class FirComponent implements OnInit {
  firnews: any;
  firdata: any;

  constructor(
    private ActivateRoute: ActivatedRoute,
    private firserv:FIRService
  ) { }

  ngOnInit(): void {
    this.ActivateRoute.data.pipe(first()).subscribe((res) => {
      if (res.firservice) {
            this.firdata =  res.firservice;
      }
    })
   
     }

}
