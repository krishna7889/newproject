import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { FirRoutingModule } from './fir-routing.module';
import { FirComponent } from './fir.component';
import { CommonsidebarModule } from '../commonsidebar/commonsidebar.module';


@NgModule({
  declarations: [FirComponent],
  imports: [
    CommonModule,
    FirRoutingModule,
    CommonsidebarModule
  ]
})
export class FirModule { }
