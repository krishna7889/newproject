import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MostpopularRoutingModule } from './mostpopular-routing.module';
import { MostpopularComponent } from './mostpopular.component';
import { CommonsidebarModule } from '../commonsidebar/commonsidebar.module';


@NgModule({
  declarations: [MostpopularComponent],
  imports: [
    CommonModule,
    MostpopularRoutingModule,
    CommonsidebarModule
  ]
})
export class MostpopularModule { }




