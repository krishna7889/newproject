import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { first } from 'rxjs/operators';
import { WebservicesService } from 'src/services/webapis';

@Component({
  selector: 'app-mostpopular',
  templateUrl: './mostpopular.component.html',
  styleUrls: ['./mostpopular.component.scss']
})
export class MostpopularComponent implements OnInit {

  mostpopular: any;

  constructor(
    private ActivateRoute: ActivatedRoute,
    private service: WebservicesService,
    private route:Router
    ) { }

    ngOnInit(): void {
      this.ActivateRoute.data.pipe(first()).subscribe((res) => {
        if (res.getmostpopulardata) {
              this.mostpopular =  res.getmostpopulardata;
        }
      })
    }

}







  


