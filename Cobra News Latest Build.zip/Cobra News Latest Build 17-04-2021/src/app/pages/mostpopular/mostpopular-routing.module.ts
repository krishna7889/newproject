import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { MostpopularComponent } from './mostpopular.component';
import { MostpopularService } from './mostpopular.service';

const routes: Routes = [{ path: '', component: MostpopularComponent,
resolve: { getmostpopulardata: MostpopularService}
 }];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class MostpopularRoutingModule { }



