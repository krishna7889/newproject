import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { first } from 'rxjs/operators';

@Component({
  selector: 'app-films',
  templateUrl: './films.component.html',
  styleUrls: ['./films.component.scss']
})
export class FilmsComponent implements OnInit {
  filmsdata: any;

  constructor(
    private ActivateRoute: ActivatedRoute,
  ) { }

  ngOnInit(): void {
    this.ActivateRoute.data.pipe(first()).subscribe((res) => {
      if (res.films) {
            this.filmsdata =  res.films;
      }
    })
  }

}
