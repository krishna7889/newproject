import { Component, OnInit } from '@angular/core';
import { DomSanitizer } from '@angular/platform-browser';
import { ActivatedRoute } from '@angular/router';
import { first } from 'rxjs/operators';
import { MovieService } from './movies.service';

@Component({
  selector: 'app-movies',
  templateUrl: './movies.component.html',
  styleUrls: ['./movies.component.scss']
})
export class MoviesComponent implements OnInit {
  movienews: any;
  content: any;
  reviews: any;
  trailers: any;
  MyordersLoader: boolean = true
  constructor(
    private ActivateRoute: ActivatedRoute,
    private moviesService: MovieService,
    public sanitizer: DomSanitizer,
  ) { }

  ngOnInit(): void {
    this.moviesService.movies().then((res) => {
      this. MyordersLoader=false
      if (res) {
        this.content = res
        // this.content[0].status=false
        // console.log(this.content)
      }
    })
    this.getreview();
    this.gettrailers();

  }

  getreview(){
    this.moviesService.moviereviews().then(res=>{
      if(res){
        this.reviews = res
        // this.reviews[0].status=false
        // console.log(this.reviews)
      }
    })
  }

  gettrailers(){
    this.moviesService.moviertrailers().then(res=>{
      if(res){
        this.trailers = res
        // this.trailers[0].status=false
        // console.log(this.trailers)
      }
    })
  }
  SafeYoutue(url:any){
    const d = 'https://youtu.be/ufgcxiKEe08'+url;
   return this.sanitizer.bypassSecurityTrustResourceUrl(d)

  }



}
