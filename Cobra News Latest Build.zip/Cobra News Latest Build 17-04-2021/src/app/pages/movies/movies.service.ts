import { Injectable } from "@angular/core";
import { ActivatedRouteSnapshot } from "@angular/router";
import { map } from "rxjs/internal/operators/map";
import { HttpClient } from '@angular/common/http';
import { tap } from 'rxjs/internal/operators/tap';
import { WebservicesService } from "src/services/webapis";
import { forkJoin } from "rxjs";


@Injectable({ providedIn: "root" })
export class MovieService {
  Accountno: any;
  // resolve(route: ActivatedRouteSnapshot) {
  //   return this.movies();
  // }

  constructor(
    private HttpClient: HttpClient,
    private service: WebservicesService
  ) { }

  movies(): Promise<any> {
    try {
      return new Promise((resolve, reject) => {
        const url = `${this.service.serviceUrl}/UT_Movie_Schedules?page=1&itemsPerPage=100`;
        this.HttpClient.get(url)
          .pipe( 
            map((d: any) => (d.code === 1 ? d.document.records : false)))
          .subscribe((r: any) => resolve(r), reject)
      });
    } catch (error) {
      console.log(error)
    }
  }

  moviereviews(): Promise<any> {
    try {
      return new Promise((resolve, reject) => {
        const url = `${this.service.serviceUrl}/UT_Movie_Reviews?page=1&itemsPerPage=100`;
        this.HttpClient.get(url)
          .pipe( 
            map((d: any) => (d.code === 1 ? d.document.records : false)))
          .subscribe((r: any) => resolve(r), reject)
      });
    } catch (error) {
      console.log(error)
    }
  }

  moviertrailers(): Promise<any> {
    try {
      return new Promise((resolve, reject) => {
        const url = `${this.service.serviceUrl}/UT_Trailers?page=1&itemsPerPage=100`;
        this.HttpClient.get(url)
          .pipe( 
            map((d: any) => (d.code === 1 ? d.document.records : false)))
          .subscribe((r: any) => resolve(r), reject)
      });
    } catch (error) {
      console.log(error)
    }
  }

  


}
