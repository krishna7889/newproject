import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-latest-news-by-category',
  templateUrl: './latest-news-by-category.component.html',
  styleUrls: ['./latest-news-by-category.component.scss']
})
export class LatestNewsByCategoryComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
