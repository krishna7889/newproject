import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { LatestNewsByCategoryRoutingModule } from './latest-news-by-category-routing.module';
import { LatestNewsByCategoryComponent } from './latest-news-by-category.component';


@NgModule({
  declarations: [LatestNewsByCategoryComponent],
  imports: [
    CommonModule,
    LatestNewsByCategoryRoutingModule
  ]
})
export class LatestNewsByCategoryModule { }
