import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { first } from 'rxjs/operators';
import { WebservicesService } from 'src/services/webapis';
import { CommonsidebarService } from './commonsidebar.service';
import { DatePipe } from '@angular/common';

@Component({
  selector: 'commonsidebar',
  templateUrl: './commonsidebar.component.html',
  styleUrls: ['./commonsidebar.component.scss']
})
export class CommonsidebarComponent implements OnInit {
  latestupdates: any;
  films: any;
  latestnewsdetails: any;
  education: any;
  content: any;
  myDate: any = new Date();
  newdate = new Date();
  day = this.newdate.getDate();
  mont = this.newdate.getMonth() + 1;
  year = this.newdate.getFullYear();
  finaldate = this.year + '-' + this.mont + '-' + this.day;
  latestnews: any;
  latestveios: any;
  latestmovierevies: any;
  constructor(
    private ActivateRoute: ActivatedRoute,
    private webservice: WebservicesService,
    private commonser: CommonsidebarService,
    private datePipe: DatePipe
  ) { }


  ngOnInit(): void {
    this.myDate = this.datePipe.transform(this.myDate, 'yyyy-MM-dd');
    this.webservice.newscontents().then(res => {
      if (res) {
        const content = res;
        this.latestupdates = content.filter(s => s.newsCategoryId === "109");

      }

    })
    this.commonser.latestnews_filter(this.finaldate).then(res => {
      if (res) {
        this.latestnews = res
        //  this.latestnews[0].status=false
      }
    })
    this.commonser.latest_vedios(this.finaldate).then(res => {
      if (res) {
        this.latestveios = res
      }
    })
    this.commonser.latest_moviesrevies(this.finaldate).then(res => {
      if (res) {
        this.latestmovierevies = res
        //  this.latestmovierevies[0].status=false
      }
    })
  }

}
