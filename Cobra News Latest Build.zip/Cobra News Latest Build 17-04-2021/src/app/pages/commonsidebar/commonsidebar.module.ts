import { NgModule } from '@angular/core';
import { CommonModule, DatePipe } from '@angular/common';

import { CommonsidebarComponent } from './commonsidebar.component';
import { RouterModule } from '@angular/router';
import { CommonsidebarService } from './commonsidebar.service';


@NgModule({
  declarations: [CommonsidebarComponent],
  imports: [
    CommonModule,
    RouterModule,
  ],
  exports:[
    CommonsidebarComponent,

  ],
  providers:[CommonsidebarService, DatePipe]

})
export class CommonsidebarModule { }
