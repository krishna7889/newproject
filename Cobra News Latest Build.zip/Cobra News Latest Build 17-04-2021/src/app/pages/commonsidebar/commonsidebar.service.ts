import { Injectable } from "@angular/core";
import { ActivatedRouteSnapshot } from "@angular/router";
import { map } from "rxjs/internal/operators/map";

import { HttpClient } from '@angular/common/http';
import { tap } from 'rxjs/internal/operators/tap';
import { WebservicesService } from "src/services/webapis";
import { forkJoin } from "rxjs";



@Injectable({ providedIn: "root" })
export class CommonsidebarService {
  Accountno: any;

  constructor(
    private HttpClient: HttpClient,
    private service: WebservicesService,

  ) {

   }

latestnews_filter(myDate): Promise<any> {
  try {
    return new Promise((resolve, reject) => {

          const url = `${this.service.serviceUrl}/UT_News_Content/filter?andOr=AND&page=1&itemsPerPage=100&Orderby=postedDate`;
      let body = [{
          "columnName": "newsCategoryId",
          "columnValue": "103",
        },{
          "columnName": "postedDate",
          "columnValue": myDate,
        }]
      this.service.Http.post(url,body)
      .pipe(
          map((d: any) => (d.code === 1 ? d.document.records : false)))
        .subscribe((r: any) => resolve(r), reject);
    });
  } catch (error) {
    console.log(error)
  }
  }

  latest_vedios(myDate): Promise<any> {
    try {
      return new Promise((resolve, reject) => {
        let body = [{

          "columnName": "postedDate",
          "columnValue": myDate,
        }]
        const url = `${this.service.serviceUrl}/UT_Videos/filter?andOr=AND&page=1&itemsPerPage=100`;
        this.HttpClient.post(url,body)
        .pipe(
            map((d: any) => (d.code === 1 ? d.document.records : false)))
          .subscribe((r: any) => resolve(r), reject);
      });
    } catch (error) {
      console.log(error)
    }
  }


  latest_moviesrevies(myDate): Promise<any> {
    try {
      return new Promise((resolve, reject) => {
        const url = `${this.service.serviceUrl}/UT_Movie_Reviews/filter?andOr=AND&page=1&itemsPerPage=100`
        let body = [{
          "columnName": "postedDate",
          "columnValue": myDate,
        }]
        this.HttpClient.post(url,body)
        .pipe(
            map((d: any) => (d.code === 1 ? d.document.records : false)))
          .subscribe((r: any) => resolve(r), reject);
      });
    } catch (error) {
      console.log(error)
    }
  }
}
