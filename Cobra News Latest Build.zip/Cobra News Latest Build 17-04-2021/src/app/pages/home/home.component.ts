import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { first } from 'rxjs/operators';
import { HomeService } from './home.service';
@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})
export class HomeComponent implements OnInit {

  newsData: any = []
  news_heading: any = [];
  newstemp_arr: any = [];
  latestnews: any;
  MyordersLoader=true
  slideOptions = {
    autoplay: true, autoplaySpeed: 500, items: 1, animateIn: 'fadeIn', margin: 0, animateOut: 'fadeOut', loop: true, navText: ['', ''], nav: true, dots: false, responsive: {
    0: {
    items: 1
    },
    400: {
    items: 1
    },
    740: {
    items: 1
    },
    940: {
    items: 1
    }
    }
    }
  banner: any = []
  nation: any;
  world: any;
  topstories: any;
  films: any;
  latestarray: any;
  constructor(
    private ActivateRoute: ActivatedRoute,
    private Home_Service: HomeService
  ) { }

  ngOnInit(): void {

    this.ActivateRoute.data.pipe(first()).subscribe((res) => {
      if (res.gethomeservice) {
      
        localStorage.setItem('cobraapitoken', res.gethomeservice.token);
        this.Home_Service.newsdata().then(r => {
          const heading = r;
          // heading[1].status=false
          // console.log(heading)
          this.Home_Service.newscontents().then(n => {
           this.MyordersLoader=false

            const content = n
            // console.log(content)
            heading.map((x: any) => {
              let value = content.filter((f: any) => f.newsCategoryId === x.newsCategoryId && x.status!==false);
              let key = x.newsCategoryName;
              this.newsData.push({
                newsCategoryName: x.newsCategoryName,
                newsCategoryId: x.newsCategoryId,
                array: value
              });
            })
            // this.newsData[0].array[0].status=false
            // console.log(this.newsData)
            this.nation = content[0]
            this.world = content[6]
            this.topstories = content[8]
            this.films = content[5]
            // setTimeout(() => {
            //   this.banner = content.filter(i => i.newsCategoryId === '103')
            //   this.banner = this.banner.reverse()
            // }, 100);
            this.latestnews = this.newsData.filter(s => s.newsCategoryId === "103");
            this.latestarray=this.latestnews[0].array
          })
        })


      }

    })




  }




}
