import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { MoviedetailsComponent } from './moviedetails.component';
import { MoviedetailsService } from './moviedetails.service';

const routes: Routes = [{ path: '', component: MoviedetailsComponent }];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class moviedetailsRoutingModule { }
