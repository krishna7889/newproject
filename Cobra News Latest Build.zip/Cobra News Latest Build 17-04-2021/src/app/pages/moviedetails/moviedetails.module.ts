import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MoviedetailsComponent } from './moviedetails.component';
import { moviedetailsRoutingModule } from './moviedetails.routing';
import { CommonsidebarModule } from '../commonsidebar/commonsidebar.module';



@NgModule({
  declarations: [MoviedetailsComponent],
  imports: [
    CommonModule,
    moviedetailsRoutingModule,
    CommonsidebarModule,

  ]
})
export class MoviedetailsModule { }
