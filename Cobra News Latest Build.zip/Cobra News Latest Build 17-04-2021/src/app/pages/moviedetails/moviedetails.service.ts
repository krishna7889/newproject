import { Injectable } from '@angular/core';
import { WebservicesService } from 'src/services/webapis';
import { HttpClient } from '@angular/common/http';
import { map } from 'rxjs/operators';
import { ActivatedRouteSnapshot } from "@angular/router";


@Injectable({
  providedIn: 'root'
})
export class MoviedetailsService {
  constructor(
    private service: WebservicesService,
    private HttpClient: HttpClient,
  ) { }

  movie_filter(filter_value): Promise<any> {
    try {
      return new Promise((resolve, reject) => {
        const url = `${this.service.serviceUrl}/UT_Movie_Schedules/filter?andOr=AND&page=1&itemsPerPage=100`;
        let body = [{
            "columnName": "sno",
            "columnValue": filter_value
          }]
        this.HttpClient.post(url,body)
        .pipe(
            map((d: any) => (d.code === 1 ? d.document.records : false)))
          .subscribe((r: any) => resolve(r), reject);
      });
    } catch (error) {
      console.log(error)
    }
  }

  moviereviews(): Promise<any> {
    try {
      return new Promise((resolve, reject) => {
        const url = `${this.service.serviceUrl}/UT_Movie_Reviews?page=1&itemsPerPage=100`;
        this.HttpClient.get(url)
          .pipe( 
            map((d: any) => (d.code === 1 ? d.document.records : false)))
          .subscribe((r: any) => resolve(r), reject)
      });
    } catch (error) {
      console.log(error)
    }
  }
  
  movies(): Promise<any> {
    try {
      return new Promise((resolve, reject) => {
        const url = `${this.service.serviceUrl}/UT_Movie_Schedules?page=1&itemsPerPage=100`;
        this.HttpClient.get(url)
          .pipe( 
            map((d: any) => (d.code === 1 ? d.document.records : false)))
          .subscribe((r: any) => resolve(r), reject)
      });
    } catch (error) {
      console.log(error)
    }
  }
}
