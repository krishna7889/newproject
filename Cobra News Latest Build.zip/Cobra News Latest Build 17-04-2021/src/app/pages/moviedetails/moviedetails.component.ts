import { Component, OnInit , OnDestroy} from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { first } from 'rxjs/operators';
import { MoviedetailsService } from './moviedetails.service';

@Component({
  selector: 'app-moviedetails',
  templateUrl: './moviedetails.component.html',
  styleUrls: ['./moviedetails.component.scss']
})
export class MoviedetailsComponent implements OnInit , OnDestroy{
  moviedetails: any;
  moviesdata: any;
private sub: any;
id: any;
  reviewsdata: any;
  MyordersLoader=true

  constructor(
    private ActivateRoute: ActivatedRoute,
    private moviedetailser:MoviedetailsService,


  ) { }

  ngOnInit(): void {
    this.sub = this.ActivateRoute.params.subscribe((params) => {
    this.id = params['movieId'];
    this.moviedetailser.movie_filter(this.id).then((res) => {
      this.MyordersLoader=false
      if(res){
        this.moviedetails = res[0];
      }
    
    });
    });
    this.getmovies();
    this.getreviews();

    }
    ngOnDestroy() {
    this.sub.unsubscribe();
    }

  getmovies(){
    this.moviedetailser.movies().then(res=>{
      if(res){
        this.moviesdata = res
        // this.moviesdata[0].status=false
        // console.log(this.moviesdata)
      }
    })
  }

  getreviews(){
    this.moviedetailser.moviereviews().then(res=>{
      if(res){
        this.reviewsdata = res
        // this.reviewsdata[0].status=false
        // console.log(this.reviewsdata)
      }
    })
  }
}
