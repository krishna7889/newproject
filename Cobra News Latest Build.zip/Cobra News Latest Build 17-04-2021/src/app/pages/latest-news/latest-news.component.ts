import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { first } from 'rxjs/operators';
import { WebservicesService } from 'src/services/webapis';

@Component({
  selector: 'app-latest-news',
  templateUrl: './latest-news.component.html',
  styleUrls: ['./latest-news.component.scss']
})
export class LatestNewsComponent implements OnInit {
  latestnews: any;

  constructor(
    private ActivateRoute: ActivatedRoute,
    private service: WebservicesService,
    private router: Router
  ) { }

  ngOnInit(): void {
    this.ActivateRoute.data.pipe(first()).subscribe((res) => {
      if (res.getlatestservice) {
            this.latestnews = res.getlatestservice
      }
    })
  }

  latestnewsDetails(data){
    localStorage.removeItem('LatestNewsData');
    localStorage.setItem('LatestNewsData',JSON.stringify(data)) ;
    this.router.navigateByUrl("LatestNewsDetails");
  }

}
