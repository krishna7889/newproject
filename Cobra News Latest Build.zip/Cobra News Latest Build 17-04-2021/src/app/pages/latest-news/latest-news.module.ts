import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { LatestNewsRoutingModule } from './latest-news-routing.module';
import { LatestNewsComponent } from './latest-news.component';
import { CommonsidebarModule } from '../commonsidebar/commonsidebar.module';


@NgModule({
  declarations: [LatestNewsComponent],
  imports: [
    CommonModule,
    LatestNewsRoutingModule,
    CommonsidebarModule
  ]
})
export class LatestNewsModule { }
