import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { LatestNewsComponent } from './latest-news.component';
import { LatestNewsService } from './latest-news.service';

const routes: Routes = [{ path: '', component: LatestNewsComponent, 
resolve: { getlatestservice: LatestNewsService } }];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class LatestNewsRoutingModule { }
