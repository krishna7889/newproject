import { Component, OnInit } from '@angular/core';
import { WebservicesService } from 'src/services/webapis';
declare var $;
declare var isRTL;
declare var $wn;
declare var $document;

@Component({
    selector: 'com-header',
    templateUrl: './header.component.html',
    styleUrls: ['./header.component.scss']
})
export class HeaderComponent implements OnInit {
    newdate = new Date();
    category: any;
    sub: any;
    constructor(
        private webser: WebservicesService
    ) { }

    ngOnInit(): void {
        this.webser.newsdata().then(res => {
            this.category = res
            // this.category[0].status=false
            this.sub = this.category.filter(s => s.newsCategoryId !== "107" && s.newsCategoryId !== "104")
        })
        this.bindnav();

    }


    bindnav() {

        /* ------------------------------------------------------------------------- *
        * COMMON VARIABLES
        * ------------------------------------------------------------------------- */
        var $wn = $(window),
            $document = $(document),
            $body = $('body'),
            isRTL = $('html').attr('dir') === 'rtl' ? true : false;

        $(function () {
            /* ------------------------------------------------------------------------- *
             * BACKGROUND IMAGE
             * ------------------------------------------------------------------------- */
            var $bgImg = $('[data-bg-img]');

            $bgImg.each(function () {
                var $t = $(this);

                $t.css('background-image', 'url(' + $t.data('bg-img') + ')')
                    .addClass('bg--img')
                    .attr('data-rjs', 2)
                    .removeAttr('data-bg-img');
            });


            /* ------------------------------------------------------------------------- *
             * STICKY
             * ------------------------------------------------------------------------- */
            var $sticky = $('[data-trigger="sticky"]');

            $sticky.each(function () {
                $(this).sticky({
                    zIndex: 999
                });
            });

            /* ------------------------------------------------------------------------- *
             * TOOLTIP
             * ------------------------------------------------------------------------- */
            var $tooltip = $('[data-toggle="tooltip"]');

            $tooltip.tooltip();

            /* ------------------------------------------------------------------------- *
             * MARQUEE
             * ------------------------------------------------------------------------- */
            var $marquee = $('[data-marquee]');

            $marquee.marquee({
                direction: isRTL ? 'right' : 'left',
                delayBeforeStart: 0,
                duration: isRTL ? 8000 : 20000,
                pauseOnHover: true,
                startVisible: true
            });

            /* ------------------------------------------------------------------------- *
             * ZOOM IMAGE
             * ------------------------------------------------------------------------- */
            var $zoomImg = $('[data-zoom="img"]');

            if ($zoomImg.length) {
                $zoomImg.zoom();
            }

            /* ------------------------------------------------------------------------- *
             * SMOOTH SCROLL
             * ------------------------------------------------------------------------- */
            var $smoothScroll = $('[data-trigger="smoothScroll"]');

            $smoothScroll.on('click', function (e) {
                e.preventDefault();

                e.$el = $(this);
                e.$target = this.hash;

                $('html, body').animate({
                    scrollTop: $(e.$target).offset().top - 60
                }, 1200);
            });


            /* ------------------------------------------------------------------------- *
             * HOVER INTENT
             * ------------------------------------------------------------------------- */
            var $hoverIntent = $('[data-trigger="hoverIntent"]');

            $hoverIntent.hoverIntent({
                selector: 'li.dropdown',
                over: function () {
                    $(this).addClass('open');
                },
                out: function () {
                    $(this).removeClass('open');
                },
                timeout: 200,
                interval: 200
            });


            /* ------------------------------------------------------------------------- *
             * MEGAMENU
             * ------------------------------------------------------------------------- */
            var $megamenu = $('.megamenu');

            $megamenu.on('click', '.dropdown-menu', function (e) {
                e.stopPropagation();
            });

            $megamenu.on('click', '.dropdown-toggle', function (e) {
                e.$el = $(this);

                if ($wn.width() < 992) {
                    if (e.$el.parent('.posts').length || e.$el.parent('.filter').length) {
                        e.preventDefault();
                        window.location = e.$el.attr('href');
                    }
                }
            });

            $megamenu.on('click', '.megamenu--filter a[data-action]', function (e) {
                var $t = $(this),
                    $megemenuPreloader = $t.parents('.megamenu').find('.megamenu--posts .preloader'),
                    ajaxUrl = $t.attr('href'),
                    action = $t.data('action'),
                    cat = $t.data('cat');

                $megemenuPreloader.fadeIn();

                $.post(ajaxUrl, {
                    action: action,
                    cat: cat
                }, function () {
                    $megemenuPreloader.fadeOut();
                });

                $t.parent('li').addClass('active').siblings().removeClass('active');

                e.preventDefault();
            });

            /* ------------------------------------------------------------------------- *
             * HEADER SECTION
             * ------------------------------------------------------------------------- */
            var $headerSearchForm = $('.header--search-form');

            $headerSearchForm.on('click', '.btn', function (e) {
                $headerSearchForm.addClass('active');

                setTimeout(function () {
                    $headerSearchForm.children('.form-control').trigger('focus');

                    $document.on('click.headerSearchForm', function (e) {
                        e.$target = $(e.target);

                        if (e.$target.not('.header--search-form').length === 0 || e.$target.parents('.header--search-form').length === 0) {
                            $headerSearchForm.removeClass('active');
                            $document.off('click.headerSearchForm');
                        }
                    });
                }, 200);
            });

            var $headerNavbar = $('.header--navbar'),
                $headerNavbarToggle = $('.header--navbar .navbar-toggle'),
                $headerNav = $('#headerNav');

            $headerNavbarToggle.on('click', function (e) {
                setTimeout(function () {
                    $document.on('click.headerNavbarToggle', function (e) {
                        e.$target = $(e.target);

                        if (e.$target.parents('#headerNav').length === 0) {
                            $headerNav.removeClass('in');
                            $headerNavbarToggle.addClass('collapsed');
                            $document.off('click.headerNavbarToggle');
                        }
                    });
                }, 200);
            });

            /* ------------------------------------------------------------------------- *
             * STICKY CONTENT
             * ------------------------------------------------------------------------- */
            var $stickyContent = $('[data-sticky-content="true"]');

            if ($stickyContent.length) {
                $stickyContent.theiaStickySidebar({
                    additionalMarginTop: $headerNavbar.length ? $headerNavbar.outerHeight() : 0
                });
            }


            /* ------------------------------------------------------------------------- *
             * CONTACT SECTION
             * ------------------------------------------------------------------------- */
            var $contactCatsLi = $('.contact--cats > .nav > li'),
                contactCatsLiH = 0;

            $contactCatsLi.each(function (e) {
                var $t = $(this),
                    height = $t.outerHeight();

                if (height > contactCatsLiH) {
                    contactCatsLiH = height;
                }

                if ($contactCatsLi.length === (e + 1)) {
                    $contactCatsLi.css('min-height', contactCatsLiH);
                }
            });

            /* ------------------------------------------------------------------------- *
             * FOOTER SECTION
             * ------------------------------------------------------------------------- */
            var $footerCopyright = $('.footer--copyright'),
                $footerSocial = $footerCopyright.find('.social'),
                $footerSocialBg = $footerCopyright.children('.social--bg');

            if (isRTL && $footerSocialBg.length) {
                $footerSocialBg.css('right', function () {
                    return $footerCopyright.outerWidth() - ($footerSocial.position().left + $footerSocial.outerWidth());
                });
            } else if (!isRTL && $footerSocialBg.length) {
                $footerSocialBg.css('left', $footerSocial.position().left);
            }

            /* ------------------------------------------------------------------------- *
             * BACK TO TOP BUTTON
             * ------------------------------------------------------------------------- */
            var $backToTop = $('#backToTop');

            $backToTop.on('click', 'a', function (e) {
                e.preventDefault();

                $('html, body').animate({
                    scrollTop: 0
                }, 1200);
            });


        });

        $wn.on('load', function () {
            /* ------------------------------------------------------------------------- *
             * BODY SCROLLING
             * ------------------------------------------------------------------------- */
            var isBodyScrolling = function () {
                if ($wn.scrollTop() > 1) {
                    $body.addClass('isScrolling');
                } else {
                    $body.removeClass('isScrolling');
                }
            };

            isBodyScrolling();
            $wn.on('scroll', isBodyScrolling);



            /* ------------------------------------------------------------------------- *
             * DROPDOWN MENU
             * ------------------------------------------------------------------------- */
            var $headerDropdownMenu = $('.header--navbar .dropdown-menu'),
                $headerDropdownMenuChild = $headerDropdownMenu.children('.dropdown');

            $headerDropdownMenu.each(function () {
                var $t = $(this),
                    $parent = $t.parent('li'),
                    space = $parent.parents('.container').width() - ($parent.position().left - 15),
                    spaceRTL = ($parent.position().left - 15) + $parent.width();

                if ($parent.parent('ul.nav').length && !$parent.hasClass('megamenu')) {
                    if (isRTL && spaceRTL < $t.width()) {
                        $parent.addClass('dropdown-left');
                    } else if (space < $t.width()) {
                        $parent.addClass('dropdown-left');
                    }
                }
            });

            if ($headerDropdownMenuChild.length) {
                $headerDropdownMenuChild.on('mouseenter', function () {
                    var $t = $(this);

                    if (typeof $t.data('switch') === 'undefined') {
                        setTimeout(function () {
                            var $dropdown = $t.children('.dropdown-menu'),
                                $parent = $t.parents('.dropdown'),
                                a = $t.parents('.container').width(),
                                b = ($parent.position().left - 15) + $t.width(),
                                c = b + $dropdown.width(),
                                e = ($parent.position().left - 15) + $parent.width(),
                                f = $t.width() + $dropdown.width(),
                                g = '';

                            $t.addClass(function () {
                                if ((isRTL && f > e) || (!isRTL && c < a)) {
                                    return 'switch--right';
                                } else if ((isRTL && f < e) || (!isRTL && c > a)) {
                                    return 'switch--left';
                                }
                            }).attr('data-switch', true);
                        }, 420);
                    }
                });
            }

            $headerDropdownMenuChild.on('click', '.dropdown-toggle', function (e) {
                e.preventDefault();
                e.stopPropagation();
            });



            /* ------------------------------------------------------------------------- *
             * PRELOADER
             * ------------------------------------------------------------------------- */
            var $bodyPreloader = $('#preloader');

            if ($bodyPreloader.length) {
                $bodyPreloader.fadeOut('slow');
            }

        });


    }


}
