export const environment = {
  production: true,
  serviceUrl: 'https://cobraapi.meanhost.in/v1/api'

};
