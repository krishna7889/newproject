export const environment = {
  production: false,
  serviceUrl: 'https://cobraapi.meanhost.in/v1/api'

};
